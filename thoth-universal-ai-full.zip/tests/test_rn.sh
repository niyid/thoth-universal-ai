#!/bin/bash
echo "Running React Native Test"
echo "Listing plugins from registry..."
curl http://localhost:5001/plugins
